import uuid
myName = str(uuid.uuid4()) # genereer unieke naam t.b.v. statistieken

import socket # get IP
myIP = socket.gethostbyname(socket.gethostname())

import os, sys # lees environment vars
GameMasterIP=os.environ["GameMasterIP"]
GameMasterPort=os.environ["GameMasterPort"]

me = { "myIP":myIP, "myName":myName }

import requests # announce self to GameMaster

def myPost(ip,pt,sv,bd):
    print("Trying in H:", "http://"+ip+":"+str(pt)+"/"+sv, bd); sys.stdout.flush();
    return requests.post("http://"+ip+":"+str(pt)+"/"+sv, json=bd)

resp = myPost(GameMasterIP,GameMasterPort,"handelaar",me)

me["port"] = resp.json()["port"]

from bottle import route, run
from bottle import request, response
from bottle import post

willTrade = None
pb = None

@post("/startSession")
def startSession():
    global pb, willTrade
    print("startSession in Handelaar",request.json); sys.stdout.flush();
    pb = request.json["pb"]
    willTrade="True"
    myPost(pb["myIP"],pb["port"],"goods",{ "Im": me, "willTrade":willTrade } )
    return "ok"

@post("/goods")
@post("/endSession")
def goods():
    global pb, willTrade
    print(request.json); sys.stdout.flush();
    willTrade = request.json["willTrade"]
    myPost(pb["myIP"],pb["port"],"goods",{ "Im": me, "willTrade":willTrade } )
    return "ok"

run(host=me['myIP'], port=me['port'], server='paste', debug=True)