#! /bin/bash
#1
export GameMasterPort=10000;
#2 
echo '' > pids
trap 'kill -9 `cat pids`' SIGINT SIGQUIT
#3
node GameMasterV2a.js 2>&1 > out &
echo $!>>pids
#4
grep -o -m 1 '[0-9.]\{7,15\}' --line-buffered >ip <( exec tail -f out); kill $!
export GameMasterIP=`cat ip`;
#6
python3 PostbusV3.py 2>&1 >>out & 
echo $!>>pids
#7
python3 HandelaarV2.py 2>&1 >>out & 
echo $!>>pids
#8
python3 HandelaarV2.py 2>&1 >>out & 
echo $!>>pids
#9
tail -f out

