var Hapi = require('hapi'),
    ip = require("ip");

var constants = { 
    port: process.env.GameMasterPort, // get shell var
    ip: ip.address() // get actual ip of this process
}

var server = new Hapi.Server();

server.connection({
    port: constants.port
});

var experiment = {
        statistics: {
            sessions: 0,
            profits: {}
        }
    }
    
server.route([
  {
    method: 'POST',
    path: '/report',
    handler: function(request, reply) {
        reply(experiment.statistics);
    }
  }
]);


server.start(function() {
  console.log(constants.ip); // return IP to pass on to other servers
});