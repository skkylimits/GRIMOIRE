Title: Rest Servers Practicum: Tit for Tat

## Rest Servers: Prisoner’s Dilemma & Tit-for-Tat

In deze handout zullen we een aantal eenvoudige REST-servers ontwikkelen en testen en we zullen ze bouwen en in gebruik nemen als docker containers.


## Inleiding

Het Prisoner’s Dilemma is een bekend filosofisch vraagstuk. De naam komt van twee verdachten die onafhankelijk ondervraagd worden. Als beide niets zeggen kunnen ze hooguit voor medeplichtigheid bestraft worden, zeg 5 jaar elk. Maar als de ene de andere aanwijst als dader krijgt die (zeg) 15 jaar en de ander krijgt geen straf.

Het Iteratieve Prisoner's Dilemma is een idee uit de speltheorie. Twee handelaren wisselen herhaald goederen uit. Dat doen ze door de goederen naar de ander te sturen. Beide kunnen de goederen die ze ontvangen pas bekijken nadat ze hun eigen inbreng verstuurd hebben. Verder communiceren ze niet.

Als ze allebij goederen sturen is dat voor beide gunstig want ze kunnen de goederen lokaal met winst verkopen (zeg +10). Maar als de ene wel iets stuurt en de ander niet is dat voor die ene zeer ongunstig en voor de ander zeer gunstig (zeg, +50 resp. -50). Als ze beide niets sturen gaan ze er niet op voor- of achteruit (±0).

Rond 1980 is er een groot experiment uitgevoerd rond het iteratieve prisoner's dilemma. Deelnemers konden een programma inzenden waarin de strategie van een Handelaar staat. Vervolgens werden er heel veel rondes gespeeld waarin steeds twee handelaren handelen zoals boven beschreven. De vraag was: welke strategie levert op den duur de meeste winst. De winnaar (uit heel veel ingezonden strategieën) was Tit-for-Tat.

* Tit-for-tat is constructief en zal in eerste instantie goedren sturen
* Maar als een opponent geen goederen stuurt zal tit-for-tat dat in de volgende ronde ook niet doen
* Zolang de opponent geen goedren stuurt zal tit-for-tat dat ook niet doen.
* Zodra de opponent goederen stuurt zal tit-for-tat dat (in de volgende ronde) ook weer doen
* Dit komt er op neer dat tit-for-tat het gedrag van de opponent uit de vorige ronde kopieert

In deze handout gaan we dit experiment bouwen. Dat wil zeggen, we bouwen een antal servers die zich als handelaren gedragen en we meten gedurende enige tijd hoe succcessvol elke Handelaar is ten opzichte van de andere handelaren.

## Servers die het experiment uitvoeren

We kunnen het experiment bouwen met drie soorten servers: 

* de Game Master (die handelaren in contact brengt en die statistieken bijhoudt)
* de Handelaren
* Postbussen (die steeds de handel tussen twee handelaren reguleren)

### Handelaar

Een Handelaar vertoont het volgende gedrag:

* meld je aan bij de Game Master
* (*) een Postbus brengt je in contact met een andere handelaar
* start een handels-sessie.  
In elke sessie
	* besluit of je wel of niet handelswaar stuurt aan de Postbus
	* van de postbus krijg je te horen of de andere handelaar handelswaar heeft gestuurd
	* van de postbus krijgt de handelaar te horen of de sessie doorgaat of wordt beëindigd 
	* als ie doorgaat: herhaal de stappen in de sessie 
* de sessie is beëindigd; wacht op een bericht van een postbus (*)

### Postbus

Een postbus vertoont het volgende cyclische gedrag:

* meldt zich aan bij de Game Master
* krijgt stuur-informatie zoals adressen van twee handelaren en de lengte van een sessie
* start een handelssessie
	* krijgt van twee handelaren wel of niet handelswaar
	* geeft het resultaat door aan de handelaren
	* stelt de sessie-statistiek bij
	* als de sessie doorgaat: herhaal de stappen
* De sessie is beëindigd; stuur statistieken aan de Game Master
* herhaal


### Game Master

De Game Master vertoont het volgende cyclische gedrag:

* accepteer verzoeken van Postbussen 
	* als de postbus statistieken rapporteert, verwerkt deze in de globale telling
	* plaats inactieve postbussen in een queue
* accepteer verzoeken van Handelaren en plaatst ze in een queue
* Als de queue met handelaren minstens 2 lang is en de queue met postbussen minstens 1:
	* maak ze in contact en start de sessie
* accepteer een verzoek van ons om de statistieken tot nu toe te geven
* accepteer een verzoek van ons om de hele sessie te herstarten

## Functioneel en Technisch Ontwerp GameMaster

Als eerste component zullen we de Game Master bouwen, omdat de andere componenten pas getest kunnen worden als de Game Master reeds bestaat.

### Game Master Services

Uit de beschrijving van de Game Master halen we de volgende services:

* `/handelaar`  
Een Handelaar meldt zich aan
* `/postbus`  
Een Postbus meldt zich voor dienst
* `/statistics`  
Een postbus geeft statistieken van de laatste sessie
* `/report`  
Rapporteer alle statistieken tot nu toe
* `/reset`  
Zet alle statistieken op nul en stuur alle Handelaren en Postbussen een `reset` opdracht

Het moet je opvallen dat van deze services, de `report` service zinvol gebruikt nog voordat de andere servers draaien. We kiezen dus die service als eerste om de server te testen.

### Game Master Data

Uit de beschrijving van de Game Master halen we dat deze de volgende data moet bijhouden:

* Handelaren  
Een lijst van alle handelaren (moeten we bijhouden om de `reset` boodschap te kunnen sturen)
* Postbussen
Een lijst van alle postbussen (moeten we bijhouden om de `reset` boodschap te kunnen sturen)
* InactieveHandelaren  
Een lijst van alle inactieve handelaren (moeten we bijhouden om een sessie te kunnen starten)
* InactievePostbussen
Een lijst van alle inactieve postbussen (moeten we bijhouden om een sessie te kunnen starten)
* Statistieken
    * Aantal ronden totaal
    * Per Handelaar:
        * Aantal ronden
        * Winst/verlies
* Constanten  
In het experiment worden enkele waarden gebruikt door alle componenten: het aantal ronden per handels-sessie, winst/verlies waarden. Een goede oplossing is, om deze waarden via de Game Master aan de componenten te geven.

## Intermezzo -- Ontwikkelomgeving

Een Docker container is een applicatie die als container is verpakt. 

Voordat je de container bouwt moet je eerst zorgen dat de applicatie werkt. Je moet eerst een ontwikkelomgeving voor de applicatie (een REST server) hebben. 

* Als je in JavaScript ontwikkelt:
    * download nodejs en nvm van [https://nodejs.org/en/download/] (https://nodejs.org/en/download/)  
    Nodejs biedt de basis om HTTP servers te bouwen, maar we gebruiken ook nog een library om het voetwerk te verrichten. Er zijn meerdere libraries om te kiezen: express, restify, koa, hapi
        * Express is oud en vertrouwd
        * Restify is de snelste maar leidt sinds versie 5 vaak onder versie-perikelen
        * Koa is mooi maar gebruikt de allernieuwste JavaScript technieken die nog niet overal ingezet worden
        * Hapi is de langzaamste maar leidt tot inzichtelijke code.  
* Als je in Python ontwikkelt:
    * Download Python [https://www.python.org/downloads/](https://www.python.org/downloads/)  
    Let op: veel systemen zoals macOS hebben al een Python versie die in het OS zelf gebruikt wordt. Dat is vaak een oude versie van Python. Laat deze versie staan en installeer daarnaast de nieuwe Python 3.6  
    Ook bij Python gebruiken we een raamwerk als basis
    * Bottle is een minimale oplossing geschikt voor kleine servers
    * Flask is meer uitgebreid en uitbreidbaar en is geschikt voor veel situaties
    * Django is een groot raamwerk dat in enterprise oplossingen gebruikt wordt

De eerste server zullen we bouwen in JavaScript met Hapi. De volgende server doen we met Python en Bottle.

## Adressering

Bij het testen en uitrollen via Docker van REST Api's moeten we even over adressering (IP nummers en poorten) nadenken.

* Op het ontwikkelplatform hebben alle servers het zelfde IP nummer (namelijk dat van de server), en moeten ze dus verschillende poorten gebruiken om te communiceren
* In de Docker omgeving hebben alle servers verschillende IP nummers om te communiceren, al dan niet met verschillende poorten

De IP nummers van de Docker containers zijn van te voren niet bekend.

In onze opzet moet één IP nummer bekend zijn: dat van de GameMaster. Immers, de andere servers melden zich eerst bij de GameMaster en geven daarbij hun actuele IP nummer door.

Hoe het adres van de GameMaster wordt doorgegeven aan de andere servers is via een 'Environment Variable'. In Linux en macOS zijn alle zogenaamde Shell Variables toegankelijk als environment variable. Een shell variable krijgt als volgt een waarde die in een server 'gelezen' kan worden.

```
export naam=waarde
```

We gebruiken dit mechansme op twee manieren. 

* het (GamMaster) poort nummer. Het is niet handig om dit in de source-code van de GameMaster te plaatsen, want de ander servers hebben het ook nodig. Om die reden bepalen we het van te voren door in de shell in te geven: `export GameMasterPort=10000`. Nu kennen alle servers het poort-nummer van de GameMaster.
* het (GameMaster) IP nummer. Het is misschien lastig dit nummer van te voren te bepalen, zeker aangezien het tijdens de test-fase een ander nummer is dan tijdens de 'Docker' fase. Om die reden rapporteert de GameMaster z'n IP nummer zodra hij 'draait' door 'm af te drukken. (het is niet echt mogelijk hier shell-variabelen voor te grbuiken die alleen doorgegeven worden aan sub-shells; maar output van een proces wordt wel doorgegeven aan de parent).  
Door deze output op te vangen en ook in een shell variabele te stoppen wordt ook het IP nummer doorgegeven.


## Game Master V1
Dit is versie 1 van de GameMaster server:

<<(GameMasterV1.js)

### Eerste Test

Testen doe je door de server te starten en met een POST-tool een bericht te posten. De eerste keer dat je de server start krijg je zoiets als
```
$ export GameMasterPort=10000
$ node GameMaster.js 
module.js:491
    throw err;
    ^

Error: Cannot find module 'hapi'
    at Function.Module._resolveFilename (module.js:489:15)
    ...
```

In de code staat `require('hapi')` maar we hebben die module nog niet op ons systeem geïnstalleerd. Dat doe je met

```
npm install hapi
```

Doe dat voor elke module die je `require`-t.

Als alles goed gaat zegt de server

```
<ip-van-je-laptop>
```

Om de server te testen hebben we een POST tool nodig, zoals  [https://www.getpostman.com/](https://www.getpostman.com/) (alle platformen)


Met het POST tool sturen we nu een bericht aan `http://<ip-van-je-laptop>:10000/report`. We laten de body leeg (het maakt voor deze service niet uit wat daarin zit).

Als alles goed gaat is het antwoord:

```
{
    "sessions": 0,
    "profits": {}
}
```



## FO en TO Handelaar + Postbus

Als 2e component maken we de Handelaar.

### Handelaar Services

* => /handelaar  
Geen service die de Handelaar zelf biedt, maar een service die de handelaar aanroept op de GameMaster. 
* /startSession  
Een postbus geeft de handelaar het startsein van een sessie. De handelaar en de postbus zullen nu de volgende berichten uitwisselen:
* => /goods `{ "goods" : true/false }`  
De handelaar stuurt een bericht aan de postbus en geeft aan of de handelswaar wel of niet gestuurd wordt.
* /goods `{ "goods" : true/false }`
De postbus zegt tegen de handelaar of de andere handelaar wel of niet handelswaar heeft gestuurd
* /endSession
De postbus zegt de handelaar dat de sessie is afgesloten


### Postbus Services

<img src="Tit-for-Tat.png" style="width:50%; float:right; ">

* => /postbus  
Geen service die de Postbus zelf biedt, maar een service die de postbus aanroept op de GameMaster. 
* /startSession `{ "one": {
De GameMaster geeft een postbus het startsein van een sessie (en geeft twee handelaren door aan de postbus). De handelaren en de postbus zullen nu de volgende berichten uitwisselen:
* /goods `{ "goods" : true/false }`  
De handelaar stuurt een bericht aan de postbus en geeft aan of de handelswaar wel of niet gestuurd wordt.
* => /goods `{ "goods" : true/false }`
De postbus zegt tegen de handelaar of de andere handelaar wel of niet handelswaar heeft gestuurd
* /endSession
De postbus zegt de handelaar dat de sessie is afgesloten
* => /statistics  
Geen service die de Postbus zelf biedt, maar een service die de postbus aanroept op de GameMaster. 



## HandelaarV1, PostbusV1 en GameMasterV2 

Voordat we de Handelaar en Postbus kunnen testen moet de GameMaster iets verder uitgebreid zijn. Deze versie implementeert twee extra services: `/handelaar` en `/postbus`:

<<(GameMasterV2.js)

Deze Handelaar gaan we in Python maken, op basis van bottle. Bottle installeer je met `pip install bottle`.

Om tussentijd testen mogelijk te maken, implementeren we nog geen services. Deze Handelaar meldt zich aan, maar accepteert maar één service-call: `startSession`. Als dit bericht wordt ontvangen (overeenkomstig met nummer 2 in de figuur hierboven) wordt alleen een boodschap afgedrukt.

De Handelaar moet wel het IP nummer en poort van de GameMaster server hebben. Om die reden 
definiëren we een shell-variabele om alle servers op de hoogte te stellen van de poort van de GameMaster. We voeren in de shell in `export GameMasterPort=10000`. 

Het IP adres van de GameMaster is pas bekend als die server wordt gestart. Om die reden print de server het eigen IP adres nadat deze gestart is. Door dat adres op te vangen kunnen we het aan andere servers doorgeven. We starten de GameMaster straks op met: 
`export GameMasterPort=10000; export GameMasterIP=$(node GameMasterV2.js)`



<<(HandelaarV1.py)

Ook de eerste test met Python programma's kan een foutmelding geven over niet-bestaande modules. 

```
$ python3 HandelaarV1.py 
Traceback (most recent call last):
  File "HandelaarV1.py", line 1, in <module>
    import requests
ModuleNotFoundError: No module named 'requests'
```

Python modules worden ingeladen met e.g. `pip install requests` 

We kunnen onderzoeken of de Handelaar zich goed heeft aangemeld door het bericht `http://192.168.0.125:10000/report` te POSTen.

De derde server is een Postbus. De code lijkt erg op die van de Handelaar (vooralsnog, omdat er nog geen services zijn geïmplementeerd).

<<(PostbusV1.py)














