import uuid
myName = str(uuid.uuid4()) # genereer unieke naam t.b.v. statistieken

import socket # get IP
myIP = socket.gethostbyname(socket.gethostname())

import os, sys # lees environment vars
GameMasterIP=os.environ['GameMasterIP']
GameMasterPort=os.environ['GameMasterPort']

me = { 'myIP':myIP, 'myName':myName }

import requests # announce self to GameMaster

def myPost(ip,pt,sv,bd):
    return requests.post("http://"+ip+":"+str(pt)+"/"+sv, json=bd)

resp = myPost(GameMasterIP,GameMasterPort,"postbus",me)

me["port"] = resp.json()["port"]

from bottle import route, run
from bottle import request, response
from bottle import post

@post('/startSession')
def startSession():
    h1=request.json["h1"]
    h2=request.json["h2"]
    pb=request.json["pb"]
    hh1=myPost(h1["myIP"],h1["port"],"startSession",pb)
    hh2=myPost(h2["myIP"],h2["port"],"startSession",pb)

run(host=me['myIP'], port=me['port'], debug=True)