import uuid
myName = str(uuid.uuid4())

import socket
myIP = socket.gethostbyname(socket.gethostname())

import requests
from bottle import route, run

print({'myIP':myIP, 'myName':myName})

response = requests.post("http://192.168.0.125:31337", data={'myIP':myIP, 'myName':myName})

print(response.text) #TEXT/HTML
print(response.status_code, response.reason) #HTTP


@route('/recipes/')
def recipes_list():
    return "LIST"

@route('/recipes/<name>', method='GET')
def recipe_show( name="Mystery Recipe" ):
    return "SHOW RECIPE " + name

@route('/recipes/<name>', method='DELETE' )
def recipe_delete( name="Mystery Recipe" ):
    return "DELETE RECIPE " + name

@route('/recipes/<name>', method='PUT')
def recipe_save( name="Mystery Recipe" ):
    return "SAVE RECIPE " + name

run(host='localhost', port=8080, debug=True)