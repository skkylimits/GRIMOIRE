import uuid
myName = str(uuid.uuid4()) # genereer unieke naam t.b.v. statistieken

import socket # get IP
myIP = socket.gethostbyname(socket.gethostname())

import os, sys # lees environment vars
GameMasterIP=os.environ['GameMasterIP']
GameMasterPort=os.environ['GameMasterPort']

me = { 'myIP':myIP, 'myName':myName }
gm= "http://"+GameMasterIP+":"+GameMasterPort

import requests # announce self to GameMaster
resp = requests.post(gm+'/postbus', json=me)

me["port"] = resp.json()["port"]

from bottle import route, run
from bottle import request, response
from bottle import post

@post('/startSession')
def startSession():
    print('received start session in Postbus'); sys.stdout.flush();
    print(request.json); sys.stdout.flush();

run(host=me['myIP'], port=me['port'], debug=True)