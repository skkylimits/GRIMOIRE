var Hapi = require('hapi'),
    ip = require("ip"),
    request=require('request');

var constants = { 
    port: process.env.GameMasterPort, // get shell var
    ip: ip.address() // get actual ip of this process
}

var server = new Hapi.Server();

server.connection({
    port: constants.port
});

var experiment = {
        handelaren: [],
        postbussen: [],
        idleHandelaren: [],
        idlePostbussen: [],
        roundsPerSession: 25,
        latestPort: +constants.port+1,
        statistics: {
            aantalHandelaren: 0,
            aantalPostbussen: 0,
            sessions: 0,
            profits: {}
        }
    }
    
server.route([
  {
    method: 'POST',
    path: '/report',
    handler: function(request, reply) {
        reply(experiment);
    }
  }
]);

function startSession() {
    var h1=experiment.idleHandelaren.pop(),
        h2=experiment.idleHandelaren.pop(),
        pb=experiment.idlePostbussen.pop();
    var options = {
        url: 'http://'+pb.myIP+':'+pb.port+'/'+'startSession',
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        json: {h1:h1, h2:h2, pb:pb }
    };
    request(options, function(err, res, body) {
        // sunny day: ignore errors
    });
}

server.route([
  {
    method: 'POST',
    path: '/handelaar',
    handler: function(request, reply) {
        var hnd = request.payload,
            port= experiment.latestPort++;
        hnd.port = port
        reply(hnd);
        experiment.handelaren.push(hnd);
        experiment.idleHandelaren.push(hnd);
        experiment.statistics.aantalHandelaren++;
        if (experiment.idleHandelaren.length>=2 && experiment.idlePostbussen.length>=1) {
            startSession()
        }
    }
  }
]);

server.route([
  {
    method: 'POST',
    path: '/postbus',
    handler: function(request, reply) {
        var pbs = request.payload,
            port= experiment.latestPort++;
        pbs.port = port
        reply(pbs);
        experiment.postbussen.push(pbs);
        experiment.idlePostbussen.push(pbs);
        experiment.statistics.aantalPostbussen++;
        if (experiment.idleHandelaren.length>2 && experiment.idlePostbussen.length>1) {
            startSession()
        }
    }
  }
]);

server.start(function() {
  console.log(constants.ip); // return IP to pass on to other servers
});