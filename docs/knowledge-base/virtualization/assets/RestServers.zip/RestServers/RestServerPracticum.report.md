Title: Rest Server Practicum

<div class="title"><small>Rest Server Practicum</small></div>

<!-- change top 2 and bottom lines -->

<div class="subtitle">System & Network Engineering 2017/2018</div>
<div class="info"> System & Network Engineering <br> (c) Pum Walters, HvA </div>
<div class="h-illustratie"></div>
<div class="v-illustratie"></div>

<div style="page-break-after:always"></div>

<<[RestServerPracticum.md]

