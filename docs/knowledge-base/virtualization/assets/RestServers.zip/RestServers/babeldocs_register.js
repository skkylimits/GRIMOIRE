var Hapi = require('hapi'),
    ip = require("ip");

var server = new Hapi.Server();

server.connection({
    port: 20000
});


function uuidv4() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

var components = {}

server.route([
  {
    method: 'POST',
    path: '/hello', // dit is de hello route
    handler: function(request, reply) {
        var uuid = uuid4(),
        	ip = request.ip,
        	port = request.port;
        reply(component[uuid] = {uuid:uuid, ip:ip, port:port});
    }
  }
]);

server.route([
  {
    method: 'POST',
    path: '/publish',
    handler: function(request, reply) {
        var uuid = request.uuid,
        	srvcs = request.services;
        component[uuid].fulfillServices = srvcs;
        reply();
        // check for matches here
    }
  }
]);

server.route([
  {
    method: 'POST',
    path: '/subscribe',
    handler: function(request, reply) {
        var uuid = request.uuid,
        	srvcs = request.services;
        component[uuid].requireServices = srvcs;
        reply();
        // check for matches here
    }
  }
]);

//=> Connect: service api => uuid, ip, port


server.start(function() {
  
});