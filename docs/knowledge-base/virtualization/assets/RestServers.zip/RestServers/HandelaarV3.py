import uuid
myName = str(uuid.uuid4()) # genereer unieke naam t.b.v. statistieken

import socket # get IP
myIP = socket.gethostbyname(socket.gethostname())

import os, sys # lees environment vars
GameMasterIP=os.environ["GameMasterIP"]
GameMasterPort=os.environ["GameMasterPort"]

me = { "myIP":myIP, "myName":myName }
gmUrL = "http://"+GameMasterIP+":"+GameMasterPort

import requests # announce self to GameMaster

def myPost(ip,pt,sv,bd):
    #print("Trying:", "http://"+ip+":"+str(pt)+"/"+sv, bd); sys.stdout.flush();
    return requests.post("http://"+ip+":"+str(pt)+"/"+sv, data=bd)

resp = myPost(GameMasterIP,GameMasterPort,"handelaar",me)

me["port"] = resp.json()["port"]

from bottle import route, run
from bottle import request, response
from bottle import post

@post("/startSession")
def startSession():
    print('HandelaarV1 received start session in Handelaar'); sys.stdout.flush();
    pass

run(host=me["myIP"], port=me["port"], debug=True)