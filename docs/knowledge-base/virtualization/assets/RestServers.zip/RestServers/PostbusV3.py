import uuid
myName = str(uuid.uuid4()) # genereer unieke naam t.b.v. statistieken

import socket # get IP
myIP = socket.gethostbyname(socket.gethostname())

import os, sys # lees environment vars
GameMasterIP=os.environ['GameMasterIP']
GameMasterPort=os.environ['GameMasterPort']

me = { 'myIP':myIP, 'myName':myName }

import requests # announce self to GameMaster

def myPost(ip,pt,sv,bd):
    print("Trying in P:", "http://"+ip+":"+str(pt)+"/"+sv, bd); sys.stdout.flush();
    return requests.post("http://"+ip+":"+str(pt)+"/"+sv, json=bd)

resp = myPost(GameMasterIP,GameMasterPort,"postbus",me)

me["port"] = resp.json()["port"]

from bottle import route, run
from bottle import request, response
from bottle import post

h1,h2,pb,t1,t2,cnt = (None,)*6


@post('/startSession')
def startSession():
    global h1,h2,pb,t1,t2,cnt
    print("startSession in Postbus",request.json); sys.stdout.flush();
    h1=request.json["h1"]
    h2=request.json["h2"]
    pb=request.json["pb"]
    t1,t2 = (None,)*2
    cnt=20
    hh1=myPost(h1["myIP"],h1["port"],"startSession",{"pb":pb})
    hh2=myPost(h2["myIP"],h2["port"],"startSession",{"pb":pb})
    return "ok"


@post("/goods")
def goods():
    global h1,h2,pb,t1,t2,cnt
    print("goods in Postbus",cnt); sys.stdout.flush();
    if t1==None:
        t1 = request.json
        print("first trade",t1); sys.stdout.flush();
        return "ok"
    else:
        t2 = request.json
        print("second trade",t2); sys.stdout.flush();
    if cnt>0:
        hh1=myPost(h1["myIP"],h1["port"],"goods",{"pb":pb,"goods":t2["willTrade"]})
        hh2=myPost(h2["myIP"],h2["port"],"goods",{"pb":pb})
    else:
        pass
    return "ok"

run(host=me['myIP'], port=me['port'], server='paste', debug=True)